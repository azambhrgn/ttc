package com.ttc.TtcProofPoint;

public class TtcProofPointApplicationTests {

	public void contextLoads() {
	}

}
