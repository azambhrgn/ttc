package com.ttc.TtcProofPoint.datamodel;

import java.util.Date;

import com.ttc.TtcProofPoint.enumration.Direction;

public class DisplayBoardEntry {
	String stationName;
	String trainId;
	Date time;
	Direction direction;

	public DisplayBoardEntry(String stationName, String trainId, Date time, Direction direction) {
		this.stationName = stationName;
		this.trainId = trainId;
		this.time = time;
		this.direction = direction;
	}

	public String getStationName() {
		return stationName;
	}

	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	public String getTrainId() {
		return trainId;
	}

	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public Direction getDirection() {
		return direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}
}
