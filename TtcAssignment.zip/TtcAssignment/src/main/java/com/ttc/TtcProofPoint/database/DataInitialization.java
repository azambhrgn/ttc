package com.ttc.TtcProofPoint.database;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ttc.TtcProofPoint.Factory;
import com.ttc.TtcProofPoint.datamodel.Intersection;
import com.ttc.TtcProofPoint.datamodel.Station;
import com.ttc.TtcProofPoint.db.DBConnection;
import com.ttc.TtcProofPoint.enumration.Direction;
import com.ttc.TtcProofPoint.enumration.Line;
import com.ttc.TtcProofPoint.enumration.TrainStatus;

public class DataInitialization {
	private static Factory factory = Factory.getFactory();

	private List<Station> stations;
	private Map<Integer, String> stationIdMapping = new HashMap<>();
	DBConnection db = new DBConnection();

	public void initStations() {
		stations = factory.getStations();
		stations.add(new Station(100, "Finch", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 0, 101, 0, 0, 0, 5)));
		stations.add(new Station(101, "North York Centre", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 100, 102, 0, 0, 5, 5)));
		stations.add(new Station(102, "Sheppard yonge", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, true, new Intersection(0, 0, 101, 103, 0, 5, 5, 5)));
		stations.add(new Station(103, "York Mills", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 102, 104, 0, 0, 5, 5)));
		stations.add(new Station(104, "Lawrence", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 103, 105, 0, 0, 5, 5)));
		stations.add(new Station(105, "Eglinton",true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 104, 106, 0, 0, 5, 5)));
		stations.add(new Station(106, "Davisville", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 105, 107, 0, 0, 5, 5)));
		stations.add(new Station(107, "St Clair", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 106, 108, 0, 0, 5, 5)));
		stations.add(new Station(108, "Summerhill", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 107, 109, 0, 0, 5, 5)));
		stations.add(new Station(109, "Rosedale", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 108, 110, 0, 0, 5, 5)));
		stations.add(new Station(110, "Bloor Yonge", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 109, 111, 0, 0, 5, 5)));
		stations.add(new Station(111, "Wellesley",true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 110, 112, 0, 0, 5, 5)));
		stations.add(new Station(112, "College", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 111, 113, 0, 0, 5, 5)));
		stations.add(new Station(113, "Dundas", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 112, 114, 0, 0, 5, 5)));
		stations.add(new Station(114, "Queen", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 113, 115, 0, 0, 5, 5)));
		stations.add(new Station(115, "King", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 114, 116, 0, 0, 5, 5)));
		stations.add(new Station(116, "Union",true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 115, 117, 0, 0, 5, 5)));
		stations.add(new Station(117, "St Andrew", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 116, 118, 0, 0, 5, 5)));
		stations.add(new Station(118, "Osgoode", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 117, 119, 0, 0, 5, 5)));
		stations.add(new Station(119, "St Patrick", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 118, 120, 0, 0, 5, 5)));
		stations.add(new Station(120, "Queen's Park", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 119, 121, 0, 0, 5, 5)));
		stations.add(new Station(121, "Museum", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 120, 122, 0, 0, 5, 5)));
		stations.add(new Station(122, "St George", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(0, 0, 121, 0, 0, 0, 5, 5)));

		// Route 2
		stations.add(new Station(131, "Bayview", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(102, 132, 0, 0, 5, 5, 0, 0)));
		stations.add(new Station(132, "Bessarion", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(131, 133, 0, 0, 5, 5, 0, 0)));
		stations.add(new Station(133, "Leslie", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(132, 134, 0, 0, 5, 5, 0, 0)));
		stations.add(new Station(134, "Don Mills", true, true, true, true, true, true, true, true, true, true, true, true,
				false, Line.YONGE, null, false, new Intersection(133, 135, 0, 0, 5, 0, 0, 0)));

	}

	public boolean stationIdMapping() {
		for (Station station : stations) {
			factory.getStationIdMapping().put(station.getId(), station);
		}
		return true;
	}

	public boolean createRoute() {

		factory.getRouteService().initiateRouteForTesting();
		return true;
	}

	public void initiateTrain() {

		factory.getTrainService().createTrain("1001", 100, 122, "08:00", 1, TrainStatus.IDEAL, "", Direction.SOUTH);
		factory.getTrainService().createTrain("1002", 100, 122, "09:00", 1, TrainStatus.IDEAL, "", Direction.SOUTH);
		factory.getTrainService().createTrain("1003", 100, 122, "10:00", 1, TrainStatus.IDEAL, "", Direction.SOUTH);
		factory.getTrainService().createTrain("1004", 100, 122, "11:00", 1, TrainStatus.IDEAL, "", Direction.SOUTH);
		factory.getTrainService().createTrain("1005", 100, 122, "12:00", 1, TrainStatus.IDEAL, "", Direction.SOUTH);
		factory.getTrainService().createTrain("1006", 122, 100, "08:00", 3, TrainStatus.IDEAL, "", Direction.NORTH);
		factory.getTrainService().createTrain("1007", 122, 100, "09:00", 3, TrainStatus.IDEAL, "", Direction.NORTH);
		factory.getTrainService().createTrain("1008", 122, 100, "10:00", 3, TrainStatus.IDEAL, "", Direction.NORTH);
		factory.getTrainService().createTrain("1009", 122, 100, "11:00", 3, TrainStatus.IDEAL, "", Direction.NORTH);
		factory.getTrainService().createTrain("1010", 122, 100, "12:00", 3, TrainStatus.IDEAL, "", Direction.NORTH);

		factory.getTrainService().createTrain("1011", 102, 126, "08:00", 2, TrainStatus.IDEAL, "", Direction.WEST);
		factory.getTrainService().createTrain("1012", 102, 126, "09:00", 2, TrainStatus.IDEAL, "", Direction.WEST);
		factory.getTrainService().createTrain("1013", 102, 126, "10:00", 2, TrainStatus.IDEAL, "", Direction.WEST);
		factory.getTrainService().createTrain("1014", 102, 126, "11:00", 2, TrainStatus.IDEAL, "", Direction.WEST);
		factory.getTrainService().createTrain("1015", 102, 126, "12:00", 2, TrainStatus.IDEAL, "", Direction.WEST);
		factory.getTrainService().createTrain("1016", 126, 102, "08:00", 4, TrainStatus.IDEAL, "", Direction.EAST);
		factory.getTrainService().createTrain("1017", 126, 102, "09:00", 4, TrainStatus.IDEAL, "", Direction.EAST);
		factory.getTrainService().createTrain("1018", 126, 102, "10:00", 4, TrainStatus.IDEAL, "", Direction.EAST);
		factory.getTrainService().createTrain("1019", 126, 102, "11:00", 4, TrainStatus.IDEAL, "", Direction.EAST);
		factory.getTrainService().createTrain("1020", 126, 102, "12:00", 4, TrainStatus.IDEAL, "", Direction.EAST);
		
		
		factory.getTrainService().initTrainMap();
	}

	// create Schedule for one train
	public void initiateScheduler() {
		factory.getSchedulerService().createSchedulerForAll();
	}

	public List<Station> getStations() {
		return stations;
	}

	public void setStations(List<Station> stations) {
		this.stations = stations;
	}

	public Map<Integer, String> getStationIdMapping() {
		return stationIdMapping;
	}

	public void setStationIdMapping(Map<Integer, String> stationIdMapping) {
		this.stationIdMapping = stationIdMapping;
	}

}
