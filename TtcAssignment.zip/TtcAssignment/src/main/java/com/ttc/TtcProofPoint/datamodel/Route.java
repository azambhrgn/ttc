package com.ttc.TtcProofPoint.datamodel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Route {
	// Route id as key
	// List of stationId as value
	Map<Integer, List<Integer>> routeMap;
	
	public Route() {
		routeMap = new HashMap<>();
	}
	
	public Map<Integer, List<Integer>> getRouteMap() {
		return routeMap;
	}

	public void setRouteMap(Map<Integer, List<Integer>> routeMap) {
		this.routeMap = routeMap;
	}
	
}
