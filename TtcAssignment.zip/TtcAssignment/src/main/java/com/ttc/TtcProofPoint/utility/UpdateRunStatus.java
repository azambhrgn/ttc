package com.ttc.TtcProofPoint.utility;

import java.util.Date;

import com.ttc.TtcProofPoint.Factory;
import com.ttc.TtcProofPoint.datamodel.Train;

public class UpdateRunStatus {
	private static Factory factory = Factory.getFactory();
	
	public void updateTheTrainRunningStatus(Train train, int stationId, Date scheduleTime, Date arrivalTime) {
		int time = (int) (( scheduleTime.getTime() - arrivalTime.getTime())/(60 * 1000) % 60);
		if(time > 0) {
			factory.getDelayStatus().put(train.getTrainId(), time);
		}
	}
}
