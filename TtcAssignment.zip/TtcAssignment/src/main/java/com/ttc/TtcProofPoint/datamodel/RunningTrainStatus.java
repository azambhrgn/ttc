package com.ttc.TtcProofPoint.datamodel;

import com.ttc.TtcProofPoint.enumration.TrainStatus;

public class RunningTrainStatus {
	private int currentStation;
	private int delayedInMinutes;
	private TrainStatus status;
	
	public RunningTrainStatus(int currentStation, int delayedInMinutes, TrainStatus status) {
		this.currentStation = currentStation;
		this.delayedInMinutes = delayedInMinutes;
		this.status = status;
	}

	public int getCurrentStation() {
		return currentStation;
	}

	public void setCurrentStation(int currentStation) {
		this.currentStation = currentStation;
	}

	public int getDelayedInMinutes() {
		return delayedInMinutes;
	}

	public void setDelayedInMinutes(int delayedInMinutes) {
		this.delayedInMinutes = delayedInMinutes;
	}

	public TrainStatus getStatus() {
		return status;
	}

	public void setStatus(TrainStatus status) {
		this.status = status;
	}
}
