package com.ttc.TtcProofPoint.datamodel;

import com.ttc.TtcProofPoint.enumration.Line;

public class Station {
	private int id;
	private String name;
	private boolean accessible;
	private boolean wifiEnable;
	private boolean prestoEnable;
	private boolean washrooms;
	private boolean tokenVendingMachine;
	private boolean passVendingMachine;
	private boolean cardPurchase;
	private boolean pickDrop;
	private Line centrePlateform; // enum type
	private Line sidePlateform; // enum type
	private boolean parking;
	private boolean goTransit;
	private boolean bramptonTransit;
	private boolean yorkTransit;
	private boolean transferRequiredToSurface;
	private Intersection intersection;
	private boolean isIntersection;
	public Station prev, next;

	public Station(int id, String name, boolean accessible, boolean wifiEnable, boolean prestoEnable, boolean washrooms,
			boolean tokenVendingMachine, boolean passVendingMachine, boolean cardPurchase, boolean pickDrop,
			 boolean parking, boolean goTransit, boolean bramptonTransit, boolean yorkTransit, boolean transferRequiredToSurface,
			Line centrePlateform, Line sidePlateform, boolean isIntersection, Intersection intersection) {
		super();
		this.id = id;
		this.name = name;
		this.accessible = accessible;
		this.wifiEnable = wifiEnable;
		this.prestoEnable = prestoEnable;
		this.washrooms = washrooms;
		this.tokenVendingMachine = tokenVendingMachine;
		this.passVendingMachine = passVendingMachine;
		this.cardPurchase = cardPurchase;
		this.pickDrop = pickDrop;
		this.centrePlateform = centrePlateform;
		this.sidePlateform = sidePlateform;
		this.parking = parking;
		this.goTransit = goTransit;
		this.bramptonTransit = bramptonTransit;
		this.yorkTransit = true;
		this.transferRequiredToSurface = true;
		this.isIntersection = isIntersection;
		this.intersection = intersection;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isAccessible() {
		return accessible;
	}

	public void setAccessible(boolean accessible) {
		this.accessible = accessible;
	}

	public boolean isWifiEnable() {
		return wifiEnable;
	}

	public void setWifiEnable(boolean wifiEnable) {
		this.wifiEnable = wifiEnable;
	}

	public boolean isPrestoEnable() {
		return prestoEnable;
	}

	public void setPrestoEnable(boolean prestoEnable) {
		this.prestoEnable = prestoEnable;
	}

	public boolean isWashrooms() {
		return washrooms;
	}

	public void setWashrooms(boolean washrooms) {
		this.washrooms = washrooms;
	}

	public boolean isTokenVendingMachine() {
		return tokenVendingMachine;
	}

	public void setTokenVendingMachine(boolean tokenVendingMachine) {
		this.tokenVendingMachine = tokenVendingMachine;
	}

	public boolean isPassVendingMachine() {
		return passVendingMachine;
	}

	public void setPassVendingMachine(boolean passVendingMachine) {
		this.passVendingMachine = passVendingMachine;
	}

	public boolean isCardPurchase() {
		return cardPurchase;
	}

	public void setCardPurchase(boolean cardPurchase) {
		this.cardPurchase = cardPurchase;
	}

	public boolean isPickDrop() {
		return pickDrop;
	}

	public void setPickDrop(boolean pickDrop) {
		this.pickDrop = pickDrop;
	}

	public Line isCentrePlateform() {
		return centrePlateform;
	}

	public void setCentrePlateform(Line centrePlateform) {
		this.centrePlateform = centrePlateform;
	}

	public Line isSidePlateform() {
		return sidePlateform;
	}

	public void setSidePlateform(Line sidePlateform) {
		this.sidePlateform = sidePlateform;
	}

	public boolean isParking() {
		return parking;
	}

	public void setParking(boolean parking) {
		this.parking = parking;
	}

	public boolean isGoTransit() {
		return goTransit;
	}

	public void setGoTransit(boolean goTransit) {
		this.goTransit = goTransit;
	}

	public boolean isBramptonTransit() {
		return bramptonTransit;
	}

	public void setBramptonTransit(boolean bramptonTransit) {
		this.bramptonTransit = bramptonTransit;
	}

	public boolean isYorkTransit() {
		return yorkTransit;
	}

	public void setYorkTransit(boolean yorkTransit) {
		this.yorkTransit = yorkTransit;
	}

	public boolean isTransferRequiredToSurface() {
		return transferRequiredToSurface;
	}

	public void setTransferRequiredToSurface(boolean transferRequiredToSurface) {
		this.transferRequiredToSurface = transferRequiredToSurface;
	}

	public Intersection getIntersection() {
		return intersection;
	}

	public void setIntersection(Intersection intersection) {
		this.intersection = intersection;
	}

	public boolean isIntersection() {
		return isIntersection;
	}

	public void setIntersection(boolean isIntersection) {
		this.isIntersection = isIntersection;
	}

}
