package com.ttc.TtcProofPoint.enumration;

public enum TrainStatus {
	IDEAL, DELAYED, RUNNING, SERVICE, CANCELLED;
}
