package com.ttc.TtcProofPoint.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;

import com.ttc.TtcProofPoint.Factory;
import com.ttc.TtcProofPoint.datamodel.Train;

public class SchedulerService {
	private static Factory factory = Factory.getFactory();

	public void createSchedulerForAll() {
		List<Train> trains = factory.getTrains();
		for (Train train : trains) {
			train.setSchedule(createSchedule(train));
		}
	}

	private Map<Integer, Date> createSchedule(Train train) {
		int route = train.getRoute();
		List<Integer> fullRouteForTrain = factory.getRoutes().getRouteMap().get(route);
		Map<Integer, Date> scheduleForTrain = new HashMap<>();
		Date trainTime = train.getStartTime();
		for (Integer stationId : fullRouteForTrain) {
			scheduleForTrain.put(stationId, trainTime);
			trainTime = DateUtils.addMinutes(trainTime, 7); // 2 for halt and 5 for traveling to other station
		}
		
		return scheduleForTrain;
	}
}
