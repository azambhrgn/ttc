package com.ttc.TtcProofPoint.enumration;

public enum Direction {
	EAST, WEST, NORTH, SOUTH;
}
