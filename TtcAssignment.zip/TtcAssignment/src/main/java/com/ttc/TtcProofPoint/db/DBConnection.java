package com.ttc.TtcProofPoint.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.TimeZone;

public class DBConnection {
	private static final String URL = "jdbc:mysql://localhost:3306/ttc?serverTimezone=" + TimeZone.getDefault().getID();
	private static final String USERID = "root";
	private static final String PWD = "March@2019";
	private Connection conn;

	public void getConnction() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(URL, USERID, PWD);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void closeConnection() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public ResultSet executeQuery(String query) {
		PreparedStatement statement;
		ResultSet rs = null;
		try {
			getConnction();
			statement = conn.prepareStatement(query);
			rs = statement.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return rs;
	}
	
	// More Methods to update and delete on Admin validation
}
