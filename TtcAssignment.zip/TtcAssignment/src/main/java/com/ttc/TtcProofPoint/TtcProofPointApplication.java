package com.ttc.TtcProofPoint;

import java.util.List;

import com.ttc.TtcProofPoint.datamodel.DisplayBoardEntry;
import com.ttc.TtcProofPoint.enumration.Direction;

public class TtcProofPointApplication {
	private static Factory factory = Factory.getFactory();
	static TtcProofPointApplication driver = new TtcProofPointApplication();

	public static void main(String[] args) {
		driver.init();
	}

	private void init() {
		// 1- Initialize the Stations
		factory.getDataInitialization().initStations();
		System.out.println("Station Initialization done");
		
		// 2- Create the route
		factory.getDataInitialization().createRoute();
		System.out.println("Route Initialization done");
		
		// 3- Create the Trains
		factory.getDataInitialization().initiateTrain();
		System.out.println("Train Initialization done");
		
		// Scheuler creation for all trains
		factory.getDataInitialization().initiateScheduler();
		System.out.println("Scheduler Initialization done");
		
		//StatioIdMapping
		factory.getDataInitialization().stationIdMapping();
		
		runTest(); // To display and check other functionality
		
	}

	private void runTest() {
		
		List<DisplayBoardEntry> display = factory.getSearch().searchTrain(102, null);
		factory.getHelper().printDisplay(display, 102);

		display = factory.getSearch().searchTrain(108, null);
		factory.getHelper().printDisplay(display, 108);
		
		display = factory.getSearch().searchTrain(133, null);
		factory.getHelper().printDisplay(display, 133);
		
		factory.getHelper().updateDelayed("1001", 5);
		display = factory.getSearch().searchTrain(108, Direction.NORTH); // call to Search
		factory.getHelper().printDisplay(display, 108);
		
		
		// Search tarin for the station in a direction after time currentTime
		String currentTime = "10:00";
		display = factory.getHelper().createDisaply(108, currentTime ,Direction.NORTH); // call to Search
		factory.getHelper().printDisplay(display, 108);
		
		//get The TrainSchedule
		String trainId = "1001";
		factory.getSearch().searchTrainSchedule(trainId);
	}
	
	
	/*
	 * TO get the shortest path
	private void createRoute() {
		List<Station> stations = factory.getStations();
		Station prev = null, next = null;
		Map<Integer, List<Integer>> routeMap = new HashMap<>();
		Map<Line, List<Station>> routes = new HashMap<>();
		
		routes.put(Line.YONGE, new ArrayList<Station>());
		routes.put(Line.SHEPARD, new ArrayList<Station>());
		
		for (int i = 0; i < stations.size(); i++) {
			Station  station = stations.get(i);
			if(station.isCentrePlateform() == Line.YONGE && station.getIntersection().getSouth() != 0) {
				station.prev = prev;
				station.next = stations.get(i + 1);
				routes.get(Line.YONGE).add(station);
				prev = station;
			}
		}
	}
	
	// Moved to service or utility
	// Services on runTime
	private static void callingFromStationToUpdateTheStatus() {
		
	}*/

}
