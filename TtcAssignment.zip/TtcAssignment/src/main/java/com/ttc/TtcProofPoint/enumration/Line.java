package com.ttc.TtcProofPoint.enumration;

public enum Line {
	YONGE, SHEPARD, BLOOR, SCRABOROUGH
}

