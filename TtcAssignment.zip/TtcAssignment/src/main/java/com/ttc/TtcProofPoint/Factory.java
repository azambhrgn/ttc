package com.ttc.TtcProofPoint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ttc.TtcProofPoint.database.DataInitialization;
import com.ttc.TtcProofPoint.datamodel.Route;
import com.ttc.TtcProofPoint.datamodel.Station;
import com.ttc.TtcProofPoint.datamodel.Train;
import com.ttc.TtcProofPoint.service.RouteService;
import com.ttc.TtcProofPoint.service.SchedulerService;
import com.ttc.TtcProofPoint.service.Search;
import com.ttc.TtcProofPoint.service.TrainService;
import com.ttc.TtcProofPoint.utility.Helper;
import com.ttc.TtcProofPoint.utility.UpdateRunStatus;

public class Factory {
	private static Factory factory;
	
	private static DataInitialization dataInitialization;
	private static Route routes;
	private static TrainService trainService;
	private static SchedulerService schedulerService;
	private static RouteService routeService;
	private static Helper helper;
	private static UpdateRunStatus updateRunStatus;
	private static Search search;
	
	private static List<Station> stations;
	private static Map<Integer, Station> stationIdMapping;
	private static List<Train> Trains;
	private static Map<String, Train> trainMap;
	private static Map<String, Integer> delayStatus;
	
	private Factory() {
		dataInitialization = dataInitialization == null ? new DataInitialization() : dataInitialization;
		routes = new Route();
		
		//Services
		trainService = new TrainService();
		schedulerService = new SchedulerService();
		routeService = new RouteService();
		updateRunStatus = new UpdateRunStatus();
		helper = new Helper();
		search = new Search();
		
		stations = new ArrayList<>();
		stationIdMapping = new HashMap<>();
		Trains = new ArrayList<Train>(); //Also create Map with TrainId as key and Train as value
		delayStatus = new HashMap<>();
		trainMap = new HashMap<>();
		
	}
	
	public static Factory getFactory() {
		if(factory == null) {
			factory = new Factory();
		}
		return factory;
	}

	public DataInitialization getDataInitialization() {
		return dataInitialization;
	}

	public Route getRoutes() {
		return routes;
	}

	public List<Station> getStations() {
		return stations;
	}

	public Map<Integer, Station> getStationIdMapping() {
		return stationIdMapping;
	}

	public List<Train> getTrains() {
		return Trains;
	}

	public TrainService getTrainService() {
		return trainService;
	}

	public SchedulerService getSchedulerService() {
		return schedulerService;
	}

	public Helper getHelper() {
		return helper;
	}

	public RouteService getRouteService() {
		return routeService;
	}

	public static Map<String, Integer> getDelayStatus() {
		return delayStatus;
	}

	public static UpdateRunStatus getUpdateRunStatus() {
		return updateRunStatus;
	}

	public static Search getSearch() {
		return search;
	}

	public static void setSearch(Search search) {
		Factory.search = search;
	}

	public static Map<String, Train> getTrainMap() {
		return trainMap;
	}

	public static void setTrainMap(Map<String, Train> trainMap) {
		Factory.trainMap = trainMap;
	}
	
}
