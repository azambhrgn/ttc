package com.ttc.TtcProofPoint.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.ttc.TtcProofPoint.Factory;
import com.ttc.TtcProofPoint.enumration.Direction;

public class RouteService {
	private static Factory factory = Factory.getFactory();
	private Integer[] route1 = { 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116,
			117, 118, 119, 120, 121, 122 };
	private Integer[] route2 = { 102, 131, 132, 133, 134 };
	private Integer[] route3 = { 122, 121, 120, 119, 118, 117, 116, 115, 114, 113, 112, 111, 110, 109, 108, 107, 106,
			105, 104, 103, 102, 101, 100 };
	private Integer[] route4 = { 134, 133, 132, 131, 102 };

	public void initiateRouteForTesting() {
		List<Integer> r1 = Arrays.asList(route1);
		List<Integer> r2 = Arrays.asList(route2);
		List<Integer> r3 = Arrays.asList(route3);
		List<Integer> r4 = Arrays.asList(route4);
		Collections.reverse(r4);
		Map<Integer, List<Integer>> routeMap = factory.getRoutes().getRouteMap();
		routeMap.put(1, r1);
		routeMap.put(2, r2);
		routeMap.put(3, r3);
		routeMap.put(4, r4);
	}

	public void createRoute(int from, int to, Direction direction) {
		ArrayList<Integer> route = new ArrayList<>();
		route.add(from);
	}
}
