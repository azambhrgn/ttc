package com.ttc.TtcProofPoint.datamodel;

public class Intersection {
	private int east;
	private int west;
	private int north;
	private int south;
	private int eastDist;
	private int westDist;
	private int northDist;
	private int southDist;
	
	public Intersection(int east, int west, int north, int south, int eastDist, int westDist, int northDist,
			int southDist) {
		super();
		this.east = east;
		this.west = west;
		this.north = north;
		this.south = south;
		this.eastDist = eastDist;
		this.westDist = westDist;
		this.northDist = northDist;
		this.southDist = southDist;
	}
	
	public int getEast() {
		return east;
	}
	public void setEast(int east) {
		this.east = east;
	}
	public int getWest() {
		return west;
	}
	public void setWest(int west) {
		this.west = west;
	}
	public int getNorth() {
		return north;
	}
	public void setNorth(int north) {
		this.north = north;
	}
	public int getSouth() {
		return south;
	}
	public void setSouth(int south) {
		this.south = south;
	}
	public int getEastDist() {
		return eastDist;
	}
	public void setEastDist(int eastDist) {
		this.eastDist = eastDist;
	}
	public int getWestDist() {
		return westDist;
	}
	public void setWestDist(int westDist) {
		this.westDist = westDist;
	}
	public int getNorthDist() {
		return northDist;
	}
	public void setNorthDist(int northDist) {
		this.northDist = northDist;
	}
	public int getSouthDist() {
		return southDist;
	}
	public void setSouthDist(int southDist) {
		this.southDist = southDist;
	}
	

}
