package com.ttc.TtcProofPoint.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.time.DateUtils;

import com.ttc.TtcProofPoint.Factory;
import com.ttc.TtcProofPoint.datamodel.DisplayBoardEntry;
import com.ttc.TtcProofPoint.datamodel.Train;
import com.ttc.TtcProofPoint.enumration.Direction;

public class Helper {
	private static Factory factory = Factory.getFactory();

	// Can search based on direction
	// More optimization needed
	public List<DisplayBoardEntry> createDisaply(int stationId) {
		List<DisplayBoardEntry> display = new ArrayList<>();

		for (Train train : Factory.getFactory().getTrains()) {
			// Search station in scheduler and if found then add
			if (train.getSchedule().containsKey(stationId)) {
				DisplayBoardEntry entry = new DisplayBoardEntry("", train.getTrainId(),
						train.getSchedule().get(stationId), train.getDirection());
				display.add(entry);
			}
		}
		return display;
	}

	public List<DisplayBoardEntry> createDisaply(int stationId, Direction direction) {
		List<DisplayBoardEntry> display = new ArrayList<>();

		for (Train train : Factory.getFactory().getTrains()) {
			// Search station in scheduler and if found then add
			if (train.getSchedule().containsKey(stationId) && train.getDirection() == direction) {
				DisplayBoardEntry entry = new DisplayBoardEntry("", train.getTrainId(),
						train.getSchedule().get(stationId), train.getDirection());
				display.add(entry);
			}
		}
		return display;
	}

	public List<DisplayBoardEntry> createDisaply(int stationId, String currentTime, Direction direction) {
		List<DisplayBoardEntry> display = new ArrayList<>();
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

		try {
			date = sdf.parse(currentTime);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		for (Train train : Factory.getFactory().getTrains()) {
			// Search station in scheduler and if found then add
			if (train.getSchedule().containsKey(stationId) && train.getDirection() == direction
					&& train.getSchedule().get(stationId).after(date)) {
				DisplayBoardEntry entry = new DisplayBoardEntry("", train.getTrainId(),
						train.getSchedule().get(stationId), train.getDirection());
				display.add(entry);
			}
		}
		return display;
	}
	
	public void printTrainSchedule(String trainId, Map<Integer, String> schedule) {
		System.out.println("********  Train "+ trainId +" Schedule **********");
		for (Entry<Integer, String> entry : schedule.entrySet()) {
			System.out.println(factory.getStationIdMapping().get(entry.getKey()).getName() + "  | " + entry.getValue());
		}
	}

	public Map<Integer, String> getTrainSchedule(String trainId) {
		Map<Integer, String> scheduler = new HashMap<>();

		for (Entry entry : factory.getTrainMap().get(trainId).getSchedule().entrySet()) {
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
			scheduler.put((Integer) entry.getKey(), sdf.format(entry.getValue()));
		}
		return scheduler;
	}

	public void updateDelayed(String trainId, int timeInMinutes) {
		HashMap<String, Integer> delayedStatus = (HashMap<String, Integer>) factory.getDelayStatus();
		delayedStatus.put(trainId, timeInMinutes);
	}

	public void printDisplay(List<DisplayBoardEntry> display, int stationId) {
		System.out.println("****** DisplayBoard " + Factory.getFactory().getStationIdMapping().get(stationId).getName()
				+ " Station *******");
		System.out.println("Ind |  Train  |               Time             | Direction");
		int i = 1;
		for (DisplayBoardEntry train : display) {
			Date updateTime = train.getTime();
			if (factory.getDelayStatus().containsKey(train.getTrainId())) {
				updateTime = DateUtils.addMinutes(updateTime, factory.getDelayStatus().get(train.getTrainId()));
			}
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

			System.out.println(i++ + "   |   " + train.getTrainId() + "  |  " + sdf.format(updateTime) + "  |  "
					+ train.getDirection());
		}
	}
}
