package com.ttc.TtcProofPoint.datamodel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.ttc.TtcProofPoint.enumration.Direction;
import com.ttc.TtcProofPoint.enumration.TrainStatus;

public class Train {
	String trainId;
	int fromStation;
	int toStation;
	Date startTime;
	int route; // Route number //
	TrainStatus status;
	String currentStation;
	Direction direction;
	Map<Integer, Date> schedule;

	public Train(String trainId, int fromStation, int toStation, String startTime, int route, TrainStatus status,
			String currentStation, Direction direction) {
		super();
		this.trainId = trainId;
		this.fromStation = fromStation;
		this.toStation = toStation;
		this.startTime = getDateForString(startTime);
		this.route = route;
		this.status = status;
		this.currentStation = currentStation;
		this.direction = direction;
		schedule = new HashMap<>();
	}

	private Date getDateForString(String date) {
		Date d = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		try {
			d = sdf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return d;
	}

	public String getTrainId() {
		return trainId;
	}

	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}

	public int getFromStation() {
		return fromStation;
	}

	public void setFromStation(int fromStation) {
		this.fromStation = fromStation;
	}

	public int getToStation() {
		return toStation;
	}

	public void setToStation(int toStation) {
		this.toStation = toStation;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public int getRoute() {
		return route;
	}

	public void setRoute(int route) {
		this.route = route;
	}

	public TrainStatus isRunning() {
		return status;
	}

	public void setRunning(TrainStatus status) {
		this.status = status;
	}

	public String getCurrentStation() {
		return currentStation;
	}

	public void setCurrentStation(String currentStation) {
		this.currentStation = currentStation;
	}

	public Direction getDirection() {
		return direction;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public Map<Integer, Date> getSchedule() {
		return schedule;
	}

	public void setSchedule(Map<Integer, Date> schedule) {
		this.schedule = schedule;
	}
}
