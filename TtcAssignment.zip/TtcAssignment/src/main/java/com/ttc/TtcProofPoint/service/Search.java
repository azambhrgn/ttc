package com.ttc.TtcProofPoint.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.ttc.TtcProofPoint.Factory;
import com.ttc.TtcProofPoint.datamodel.DisplayBoardEntry;
import com.ttc.TtcProofPoint.datamodel.RunningTrainStatus;
import com.ttc.TtcProofPoint.enumration.Direction;
import com.ttc.TtcProofPoint.enumration.TrainStatus;

public class Search {
	private static Factory factory = Factory.getFactory();
	
	public List<DisplayBoardEntry> searchTrain(int st_id, Direction direction) {
		// validation for station and direction
		return direction == null ? factory.getHelper().createDisaply(st_id) : factory.getHelper().createDisaply(st_id, direction);
	}
	
	// Get TrainSchedule
	public void searchTrainSchedule(String trainId) {
		Map<Integer, String> schedule = factory.getHelper().getTrainSchedule(trainId);
		factory.getHelper().printTrainSchedule(trainId, schedule);
	}
	
	// Get All paths // Can use DiJacstra
	public List<List<Integer>> getAllPaths(Integer fromStation, Integer toStation) {
		return null;
	}
	
	// get current Status of Train
	public RunningTrainStatus getCurrentStatus(String trainId) {
		RunningTrainStatus status = new RunningTrainStatus(111, 5, TrainStatus.DELAYED);
		return status;
	}
}
