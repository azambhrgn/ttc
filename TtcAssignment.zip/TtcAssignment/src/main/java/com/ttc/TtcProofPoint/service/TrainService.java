package com.ttc.TtcProofPoint.service;

import java.util.List;
import java.util.Map;

import com.ttc.TtcProofPoint.Factory;
import com.ttc.TtcProofPoint.datamodel.Train;
import com.ttc.TtcProofPoint.enumration.Direction;
import com.ttc.TtcProofPoint.enumration.TrainStatus;

public class TrainService {
	private static Factory factory = Factory.getFactory();

	public boolean createTrain(String trainId, int fromStation, int toStation, String startTime, int route,
			TrainStatus status, String currentStation, Direction direction) {
		factory.getTrains()
				.add(new Train(trainId, fromStation, toStation, startTime, route, status, currentStation, direction));
		return true;
	}
	
	public void initTrainMap() {
		List<Train> trains = factory.getTrains();
		Map<String, Train> map = factory.getTrainMap();
		for (Train train : trains) {
			map.put(train.getTrainId(), train);
		}
	}
	
}
